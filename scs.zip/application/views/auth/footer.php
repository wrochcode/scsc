
 
                    <div class="text-center mt-5 text-small">
                        Copyright &copy;<a href="<?= base_url();?>" class="text-dark">SCSC</a>. Made with 💙 by Stisla
                    <!-- <div class="mt-2">
                        <a href="#">Privacy Policy</a>
                        <div class="bullet"></div>
                        <a href="#">Terms of Service</a>
                    </div> -->
                    </div>
                </div>
                </div>
                <div class="col-lg-8 col-12 order-lg-2 order-1 min-vh-100 background-walk-y position-relative overlay-gradient-bottom" data-background="<?php echo base_url(); ?>/assets/login/img/unsplash/login-bg.jpg">
                <!-- <div class="col-lg-8 col-12 order-lg-2 order-1 min-vh-100 background-walk-y position-relative overlay-gradient-bottom" data-background="<?php echo base_url(); ?>/assets/login/img/dinus/udinusgedung.jpeg"> -->
                <div class="absolute-bottom-left index-2">
                    <div class="text-light p-5 pb-2">
                    <div class="mb-5 pb-3">
                        <!-- <h1 class="mb-2 display-4 font-weight-bold">Good Morning</h1> -->
                        <script type="text/javascript">
                            var d = new Date();
                            var time = d.getHours();
                            if (time<10)
                            {
                                document.write('<h1 class="mb-2 display-4 font-weight-bold">Selamat Pagi</h1>');
                            }
                            else if (time>=10 && time<15)
                            {
                                document.write('<h1 class="mb-2 display-4 font-weight-bold">Selamat Siang</h1>');
                            }
                            else if (time>=15 && time<18)
                            {
                                document.write('<h1 class="mb-2 display-4 font-weight-bold">Selamat Sore</h1>');
                            }
                            else
                            {
                                document.write('<h1 class="mb-2 display-4 font-weight-bold">Selamat Malam</h1>');
                            }
                        </script>
                        <!-- <h1 class="mb-2 display-4 font-weight-bold">Good Morning</h1> -->
                        <h5 class="font-weight-normal text-muted-transparent">Bali, Indonesia</h5>
                    </div>
                        Photo by <a class="text-light bb" target="_blank" href="https://unsplash.com/photos/a8lTjWJJgLA">Justin Kauffman</a> on <a class="text-light bb" target="_blank" href="https://unsplash.com">Unsplash</a>
                    </div>
                </div>
                </div>
            </div>
        </section>
    </div>

 <!-- General JS Scripts -->
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/login/js/stisla.js"></script>

  <!-- JS Libraies -->

  <!-- Template JS File -->
  <script src="<?php echo base_url(); ?>/assets/login/js/scripts.js"></script>
  <script src="<?php echo base_url(); ?>/assets/login/js/custom.js"></script>

  <!-- Page Specific JS File -->
</body>
</html>