            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card gradient-bottom">
                                <div class="card-header">
                                    <h4>Pemberitahuan</h4>
                                </div>
                                <div class="card-body">
                                    <div class="list-group">
                                        <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                                            <div class="d-flex w-100 justify-content-between">
                                                <p class="mb-1"><b>Pesanan service telah diverifikasi</b></p>
                                                <small>1 hour ago</small>
                                            </div>
                                            <p class="mb-1">Penyesuaian jadwal oleh admin.</p>
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                                            <div class="d-flex w-100 justify-content-between">
                                                <p class="mb-1"><b>Pesanan barang telah samapai tempat tujuan</b></p>
                                                <small>3 days ago</small>
                                            </div>
                                            <p class="mb-1">Pesanan telah diterima oleh pacar.</p>
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                                            <div class="d-flex w-100 justify-content-between">
                                                <p class="mb-1"><b>Pesanan service telah terselesaikan</b></p>
                                                <small>1 week ago</small>
                                            </div>
                                            <p class="mb-1">Transaksi berhasil dilakukan.</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>