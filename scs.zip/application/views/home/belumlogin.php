

  <main id="main">

    <!-- ======= Featured Section ======= -->
    

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container mt-lg-5">
          <br><br><br><br><br><br>
        <div class="section-title animate__animated animate__fadeInUp" data-aos="fade-up">
          <h2>Login untuk melihat keranjang</h2>
        </div>
        <div class="section-title" data-aos="fade-up">
          <a href="<?= base_url()?>login"><button class="btn-success">Login</button></a>
        </div>

      </div>
    </section><!-- End Services Section -->
    <br><br><br><br><br><br>

    <!-- ======= Clients Section ======= -->
    <!-- <section id="clients" class="clients">
      <div class="container">

        <div class="section-title">
          <h2>Clients</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class="owl-carousel clients-carousel">
          <img src="assets/img/clients/client-1.png" alt="">
          <img src="assets/img/clients/client-2.png" alt="">
          <img src="assets/img/clients/client-3.png" alt="">
          <img src="assets/img/clients/client-4.png" alt="">
          <img src="assets/img/clients/client-5.png" alt="">
          <img src="assets/img/clients/client-6.png" alt="">
          <img src="assets/img/clients/client-7.png" alt="">
          <img src="assets/img/clients/client-8.png" alt="">
        </div>

      </div>
    </section> -->
    <!-- End Clients Section -->

  </main><!-- End #main -->
